<?php
class ControllerExtensionShippingSuntechLogistic extends Controller 
{
	//fatfat
	private $errer = [];
    private $errer_p = [
		'methods',
	];
    private $module_name = 'shipping_suntechlogistic';
    private $extension_route = 'marketplace/extension';

    // Constructor
    public function __construct($registry) {
        parent::__construct($registry);

        $this->module_code = 'shipping_suntechlogistic';
        $this->lang_prefix = 'suntechlogistic_';
        $this->module_path = 'extension/shipping/suntechlogistic';
    }

    // Back-end config index page
    public function index() {
        
		$this->load->language($this->module_path);

		$heading_title = $this->language->get('heading_title');
        $this->document->setTitle($heading_title);

		$this->load->model('setting/setting');
		$token = $this->session->data['user_token'];

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {

			if($this->request->post['shipping_suntechlogistic_status'] == '1'){
				$this->model_setting_setting->editSetting('payment_suntechlogistic', ['payment_suntechlogistic_status'=>'1']);
			}else{
				$this->model_setting_setting->editSetting('payment_suntechlogistic', ['payment_suntechlogistic_status'=>'0']);
			}

            $this->model_setting_setting->editSetting($this->module_code, $this->request->post);
            
            $this->session->data['success'] = $this->language->get('text_success');

            $redirect_url = $this->url->link($this->extension_route,'user_token=' . $token . '&type=shipping',true);
			$this->response->redirect($redirect_url);
			
        }



		$data['heading_title'] = $heading_title;

		$lang_names = [
            'text_enabled',
			'text_disabled',
			'text_all_zones',
			'entry_status',
			'entry_sort_order',
			'entry_shipping_ecpaylogistic_methods1',
			'entry_shipping_ecpaylogistic_methods2',
			'entry_shipping_ecpaylogistic_methods3',
			'entry_shipping_ecpaylogistic_methods4',
			'entry_shipping_ecpaylogistic_methods5',
		];
		
        foreach ($lang_names as $name) {
            $data[$name] = $this->language->get($name);
        }
		
        unset($lang_names);

        
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

        foreach ($this->errer_p as $name) { 
 
            if (isset($this->error[$name])) {
                $data['error_'.$name] = $this->error[$name];
            } else {
                $data['error_'.$name] = '';
            }

		}
		


		$data['breadcrumbs'] = [
			[
				'text' => $this->language->get('text_home'),
				'href' => $this->url->link('common/dashboard', 'user_token=' . $token, true)
			],
			[
				'text' => $this->language->get('text_payment'),
				'href' => $this->url->link('marketplace/extension', 'user_token=' . $token . '&type=shipping', true)
			],
			[
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link($this->module_path, 'user_token=' . $token , true)
			],
		];
		
		$data['action'] = $this->url->link($this->module_path, 'user_token=' . $token, true);
		$data['cancel'] = $this->url->link($this->extension_route, 'user_token=' . $token. '&type=shipping', true);


		$options = [
			'shipping_suntechlogistic_methods',
			'shipping_suntechlogistic_status',
			'shipping_suntechlogistic_sort_order',
			'shipping_suntechlogistic_geo_zone_id',
			'shipping_suntechlogistic_cost',
			'shipping_suntechlogistic_EDIcost',
			'shipping_suntechlogistic_EDItype'
			
        ];
        foreach ($options as $name) { 
 
            if (isset($this->request->post[$name])) {
                $data[$name] = $this->request->post[$name];
            } else {
                $data[$name] = $this->config->get($name);
            }

		}

        unset($options);
		$_['entry_shipping_ecpaylogistic_methods1']       = '7-11';
		$_['entry_shipping_ecpaylogistic_methods2']       = '全家';
		$_['entry_shipping_ecpaylogistic_methods3']       = '全家集倉';
		$_['entry_shipping_ecpaylogistic_methods4']       = '萊爾富';
		$_['entry_shipping_ecpaylogistic_methods5']       = 'OK商店';
		$_['entry_shipping_ecpaylogistic_methods6']       = '宅配通';
		$data['shipping_methods'] = [
			'1' => '7-11',
			'2' => '全家',
			'2B' => '全家集倉',
			'3' => 'OK商店',
			'4' => '萊爾富',
			'E' => '宅配通'
		];

		$data['shipping_methods_EDI'] = ['S60','S90','S120','S150'];

		$data['shipping_methods_EDI_type'] = [
			'G' => '常溫',
			'F' => '冷藏',
			'I' => '冷凍',
		];

		// Get the order statuses
		$this->load->model('localisation/order_status');
		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

		// Get the geo zones
		$this->load->model('localisation/geo_zone');
		$data['geo_zones'] = $this->model_localisation_geo_zone->getGeoZones();

        // common's page
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view($this->module_path, $data));
    }

    protected function validate() {

		$requ = $this->request->post;
		if($requ['shipping_suntechlogistic_status'] == '1'){

			if(empty($requ['shipping_suntechlogistic_methods'])){
				$this->error = [ 'error_shipping_suntechlogistic_methods' => $this->language->get('error_shipping_suntechlogistic_methods')];

			}
			
		}

		if (!$this->error) {
			return true;
		} else {
			return false;
		}
    }

    public function install() {
        
		$this->load->model('setting/setting');
		$this->model_setting_setting->editSetting($this->module_name, [$this->module_name.'_status' => 1]);
		$this->model_setting_setting->editSetting($this->module_name, [$this->module_name.'_order_status_id' => 2]);

		$this->load->model('setting/event');
		$this->model_setting_event->addEvent('suntech_fatfat_payment_method', 'catalog/model/setting/extension/getExtensions/after', 'extension/payment/suntechfatfat/index');
    }

    public function uninstall() {
        $this->load->model('setting/setting');
        $this->load->model('setting/extension');

        $this->model_setting_setting->deleteSetting($this->request->get['extension']);
        $this->model_setting_extension->uninstall($this->module_code, $this->request->get['extension']);

        $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "order_extend`;");
    }
}
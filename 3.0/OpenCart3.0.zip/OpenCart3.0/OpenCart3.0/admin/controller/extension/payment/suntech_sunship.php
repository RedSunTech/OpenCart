<?php 
class ControllerExtensionPaymentSuntechSunship extends Controller {
    
	private $error = array();
	private $errer_p = [
		'account',
		'password',
	];
    private $module_name = 'payment_suntech_sunship';
    private $extension_route = 'marketplace/extension';

    // Constructor
    public function __construct($registry) {
        parent::__construct($registry);

        $this->module_code = 'payment_suntech_sunship';
        $this->lang_prefix = 'suntech_sunship_';
        $this->module_path = 'extension/payment/suntech_sunship';
    }

    // Back-end config index page
    public function index() {
        
		$this->load->language($this->module_path);

		$heading_title = $this->language->get('heading_title');
        $this->document->setTitle($heading_title);

		$this->load->model('setting/setting');
		$token = $this->session->data['user_token'];

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {

            $this->model_setting_setting->editSetting($this->module_code, $this->request->post);
            
            $this->session->data['success'] = $this->language->get('text_success');

            $redirect_url = $this->url->link($this->extension_route,'user_token=' . $token . '&type=payment',true);
			$this->response->redirect($redirect_url);
			
        }



		$data['heading_title'] = $heading_title;

		$lang_names = [
            'text_enabled',
			'text_disabled',
			'text_all_zones',
			'entry_test_mode',
			'entry_account',
			'entry_account_note',
			'entry_password',
			'entry_order_status',
			'entry_geo_zone',
			'entry_status',
			'entry_sort_order',
			'button_save',
			'button_cancel',
			'tab_general',
		];
		



        foreach ($lang_names as $name) {
            $data[$name] = $this->language->get($name);
        }
		
        unset($lang_names);


        if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

        foreach ($this->errer_p as $name) { 
 
            if (isset($this->error[$name])) {
                $data['error_'.$name] = $this->error[$name];
            } else {
                $data['error_'.$name] = '';
            }

        }




		$data['breadcrumbs'] = [
			[
				'text' => $this->language->get('text_home'),
				'href' => $this->url->link('common/dashboard', 'user_token=' . $token, true)
			],
			[
				'text' => $this->language->get('text_payment'),
				'href' => $this->url->link('marketplace/extension', 'user_token=' . $token . '&type=payment', true)
			],
			[
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link($this->module_path, 'user_token=' . $token , true)
			],
		];
		
		$data['action'] = $this->url->link($this->module_path, 'user_token=' . $token, true);
		$data['cancel'] = $this->url->link($this->extension_route, 'user_token=' . $token. '&type=payment', true);


		$options = [
            'payment_suntech_sunship_test_mode',
            'payment_suntech_sunship_account',
            'payment_suntech_sunship_password',
			'payment_suntech_sunship_order_status_id',
			'payment_suntech_sunship_geo_zone_id',
			'payment_suntech_sunship_status',
			'payment_suntech_sunship_sort_order',
			
        ];
        foreach ($options as $name) { 
 
            if (isset($this->request->post[$name])) {
                $data[$name] = $this->request->post[$name];
            } else {
                $data[$name] = $this->config->get($name);
            }

        }
        unset($options);



		// Get the order statuses
		$this->load->model('localisation/order_status');
		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

		// Get the geo zones
		$this->load->model('localisation/geo_zone');
		$data['geo_zones'] = $this->model_localisation_geo_zone->getGeoZones();

        // common's page
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view($this->module_path, $data));
    }

    protected function validate() {

		if (!$this->user->hasPermission('modify', $this->module_path)) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		foreach ($this->errer_p as $name) { 
            if (!$this->request->post[$this->module_code.'_'.$name]) {
				$this->error = [ $name => $this->language->get('error_'.$name)];
			}

		}

		if (!$this->error) {
			return true;
		} else {
			return false;
		}
    }

    public function install() {
        
		$this->load->model('setting/setting');
		$this->model_setting_setting->editSetting($this->module_name, [$this->module_name.'_status' => 1]);
		$this->model_setting_setting->editSetting($this->module_name, [$this->module_name.'_order_status_id' => 2]);
    }

    public function uninstall() {
        $this->load->model('setting/setting');
        $this->load->model('setting/extension');

        $this->model_setting_setting->deleteSetting($this->request->get['extension']);
        $this->model_setting_extension->uninstall($this->module_code, $this->request->get['extension']);

        $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "order_extend`;");
    }
}

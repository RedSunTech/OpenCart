<?php
// Heading
$_['heading_title']      = '紅陽科技物流';

// Text 
$_['text_payment']       = '運送模組'; 
$_['text_success']       = $_['heading_title'] . '資料修改成功！';
$_['text_suntech_24pay']       = '<a onclick="window.open(\'https://www.esafe.com.tw\');"><img src="view/image/payment/suntech.png" alt="紅陽科技金流服務" title="紅陽科技金流服務" style="border: 1px solid #EEEEEE;" /></a>';

// Entry


$_['entry_shipping_ecpaylogistic_methods1']       = '7-11';
$_['entry_shipping_ecpaylogistic_methods2']       = '全家';
$_['entry_shipping_ecpaylogistic_methods3']       = '全家集倉';
$_['entry_shipping_ecpaylogistic_methods4']       = '萊爾富';
$_['entry_shipping_ecpaylogistic_methods5']       = 'OK商店';
$_['entry_shipping_ecpaylogistic_methods6']       = '宅配通';

$_['entry_cargo']       = '選擇物流';
$_['entry_status']       = '狀態';
$_['entry_sort_order']   = '排序';
$_['entry_geo_zone']   = '適用地區';


// Error
$_['error_shipping_suntechlogistic_methods']   = '至少選擇一種物流';

?>
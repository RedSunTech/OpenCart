<?php

class SunPayFactory
{
    public static function newSunPay($payment, $shipment = null, $installments = '')
    {

        switch ($payment) {
            case 'suntech_unionpay':
            case 'suntech_buysafe':
                return new BuySafe($payment, $shipment, $installments);
                break;
            case 'suntech_webatm':
                return new WebATM($payment, $shipment);
                break;
            case 'suntech_sunship':
                return new SunShip($payment, $shipment);
                break;
            case 'suntech_24pay':
                return new Pay24($payment, $shipment);
                break;
            case 'suntech_paycode':
                return new PayCode($payment, $shipment);
                break;
            case 'suntech_atmcode':
                return new AtmCode($payment, $shipment);
                break;
            case 'suntech_applepay':
                return new ApplePay($payment, $shipment);
                break;
            case 'suntech_googlepay':
                return new GooglePay($payment, $shipment);
                break;
            case 'suntech_twpay':
                return new TwPay($payment, $shipment);
                break;
            default:
                throw new Exception('Undefined payment');
        }
    }
    
    public static function success_ship($shipping_method = '7-11'){ 

        //fatfat
        $ck_url = [
            '7-11'=>'https://eservice.7-11.com.tw/e-tracking/search.aspx',
            '全家'=>'https://www.famiport.com.tw/Web_Famiport/page/process.aspx',
            'OK商店'=>'https://ecservice.okmart.com.tw/Tracking/Search',
            '萊爾富'=> 'https://www.hilife.com.tw/serviceInfo_search.aspx',
            '宅配通'=> 'https://www.e-can.com.tw/search_Goods.aspx',
        ];

        if($shipping_method == '宅配通'){

            return array('text_success_ecan',$ck_url[$shipping_method]);

        }else{

            return array('text_success_ship',$ck_url[$shipping_method]);

        }
         
    }


    public static function EDI($password,$order_info, $POST,$CargoFlag,$custom_field){
        //fatfat

        $custom_field_id = '';

        foreach($custom_field as $k => $v){

            if(($v['name'] == '手機' || $v['name'] == '行動電話' || $v['name'] == 'mobile' ) && $v['location'] == 'address' ){

                $custom_field_id = $v['custom_field_id'];
            }
            
        }
        $EDI_Tel = $order_info['telephone'];

        if(!empty($order_info['shipping_custom_field'][$custom_field_id])){
            $tel = $order_info['shipping_custom_field'][$custom_field_id];
            $tel = str_replace("-","",$tel);
            $tel = str_replace("(","",$tel);
            $tel = str_replace(")","",$tel);
            $tel = str_replace("（","",$tel);
            $tel = str_replace("）","",$tel);
            $tel = str_replace("[","",$tel);
            $tel = str_replace("]","",$tel);
            if(strlen($tel) == 10 && is_numeric($tel)){
                $EDI_Tel = $tel;
            }
        }
    

        if( $CargoFlag  == 'E' ){    
            $input = [
                'EDI_Name' => $order_info['shipping_lastname'].$order_info['shipping_firstname'],
                'EDI_Tel' => $EDI_Tel,
                'EDI_Address' => $order_info['shipping_zone'].$order_info['shipping_city'].$order_info['shipping_address_1'].$order_info['shipping_address_2'],
                'EDI_Size' => $POST['EDI_Size'],
                'EDI_Type' => $POST['EDI_Type'],
            ];
        }else{
            $input = [
                'EDI_Name' => $order_info['shipping_lastname'].$order_info['shipping_firstname'],
                'EDI_Tel' => $EDI_Tel,
            ];
        }

        $input = json_encode($input);

        if (strlen($input) % 8) {
            $input = str_pad($input,strlen($input) + 8 - strlen($input) % 8, "#");
        }

        $kk = substr($password, 0, 8);

        $key = '1234567890'.$kk.'123456';

        $output = openssl_encrypt($input, 'des-ede3', $key, OPENSSL_ZERO_PADDING); 

        return $output;

    }


}

Abstract class SunPay
{
    public $sendField = array();
    public $sendExtendField = array();

    function __construct()
    {
        $this->sendField = array(
            'web' => '',
            'MN' => '',
            'OrderInfo' => '',
            'Td' => '',
            'sna' => '',
            'sdt' => '',
            'email' => '',
            'note1' => '',
            'note2' => '',
            'CargoFlag' => 0,
            'StoreID' => '',
            'StoreName' => '',
            'ChkValue' => ''
        );
    }

    function setCargoFlag($shipment_text)
    {	
		/*
        if ($shipment_text == 'ship') {
            $this->sendField['CargoFlag'] = 1;
        }*/
		$this->sendField['CargoFlag'] = $shipment_text;
    }

    function setChkValue($transaction_pwd)
    {
        $chk_value = $this->sendField['web'] . $transaction_pwd . $this->sendField['MN'];
        if (isset($this->sendExtendField['Term']) && $this->sendExtendField['Term'] != '') {
            $chk_value = $chk_value . $this->sendExtendField['Term'];
        }
        $this->sendField['ChkValue'] = EncryptChkValue::getValue($chk_value);
    }

    function checkOutHtmlParameters($webPwd)
    {
        $this->setChkValue($webPwd);
        $encode_parameters = array();
        $parameters = array_merge($this->sendField, $this->sendExtendField);
        foreach ($parameters as $key => $parameter) {
            $encode_parameters[$key] = urlencode($parameter);
        }
        return $encode_parameters;
    }

    function verifyCallBack($chkValue)
    {
        if ($_POST['ChkValue'] != $chkValue) {
            return false;
        }
        return true;
    }
}


class BuySafe extends SunPay
{
    private $payment, $installments;
    public $sendExtendField = array(
        'Card_Type' => 0,
        'Country_Type' => '',
        'Term' => '',
    );

    function __construct($payment, $shipment = null, $installments = '')
    {
        parent::__construct();
        $this->payment = $payment;
        $this->installments = $installments;

        $this->setCargoFlag($shipment);

        if ($this->payment == 'suntech_buysafe') {
            if (!in_array($this->installments, array('', '3', '6', '12', '18', '24' ,'30'))) {
                throw new Exception('installments exception');
            }
            $this->sendExtendField['Term'] = $this->installments;
        } elseif ($this->payment == 'suntech_unionpay') {
            $this->sendExtendField['Card_Type'] = 1;
        }
    }

    public function CallBack($webPwd)
    {
        $call_back_by_shipment = false;
        $errorCode = $_POST['errcode'];

        if ($_POST['MN']) {
            $chkValue = $_POST['web'] . $webPwd . $_POST['buysafeno'] . $_POST['MN'] . $errorCode;
            if ($_POST['CargoNo'] != '') {
                $chkValue = $chkValue . $_POST['CargoNo'];
            }
        } else {
            $call_back_by_shipment = true;
            $chkValue = $_POST['web'] . $webPwd . $_POST['buysafeno'] . $_POST['StoreType'];
        }

        $chkValue = EncryptChkValue::getValue($chkValue);
        $response['chkValue'] = $this->verifyCallBack($chkValue);
        $response['shipment'] = $call_back_by_shipment;
        return $response;
    }
}
class ApplePay extends SunPay
{
    private $payment, $installments;
    public $sendExtendField = array(
        'Card_Type' => 3,
        'Country_Type' => '',
        'Term' => '',
    );

    function __construct($payment, $shipment = null, $installments = '')
    {
        parent::__construct();
        $this->payment = $payment;

        $this->setCargoFlag($shipment);

    }

    public function CallBack($webPwd)
    {
        $call_back_by_shipment = false;
        $errorCode = $_POST['errcode'];

        if ($_POST['MN']) {
            $chkValue = $_POST['web'] . $webPwd . $_POST['buysafeno'] . $_POST['MN'] . $errorCode;
            if ($_POST['CargoNo'] != '') {
                $chkValue = $chkValue . $_POST['CargoNo'];
            }
        } else {
            $call_back_by_shipment = true;
            $chkValue = $_POST['web'] . $webPwd . $_POST['buysafeno'] . $_POST['StoreType'];
        }

        $chkValue = EncryptChkValue::getValue($chkValue);
        $response['chkValue'] = $this->verifyCallBack($chkValue);
        $response['shipment'] = $call_back_by_shipment;
        return $response;
    }
}
class GooglePay extends SunPay
{
    private $payment, $installments;
    public $sendExtendField = array(
        'Card_Type' => 3,
        'Country_Type' => '',
        'Term' => '',
    );

    function __construct($payment, $shipment = null, $installments = '')
    {
        parent::__construct();
        $this->payment = $payment;

        $this->setCargoFlag($shipment);

    }

    public function CallBack($webPwd)
    {
        $call_back_by_shipment = false;
        $errorCode = $_POST['errcode'];

        if ($_POST['MN']) {
            $chkValue = $_POST['web'] . $webPwd . $_POST['buysafeno'] . $_POST['MN'] . $errorCode;
            if ($_POST['CargoNo'] != '') {
                $chkValue = $chkValue . $_POST['CargoNo'];
            }
        } else {
            $call_back_by_shipment = true;
            $chkValue = $_POST['web'] . $webPwd . $_POST['buysafeno'] . $_POST['StoreType'];
        }

        $chkValue = EncryptChkValue::getValue($chkValue);
        $response['chkValue'] = $this->verifyCallBack($chkValue);
        $response['shipment'] = $call_back_by_shipment;
        return $response;
    }
}
class WebATM extends SunPay
{
    public $sendExtendField = array(
        'AgencyType' => 2,
    );

    function __construct($payment,$shipment = null)
    {
        parent::__construct();
        $this->setCargoFlag($shipment);
    }
    public function CallBack($webPwd)
    {
        $call_back_by_shipment = false;
        $errorCode = $_POST['errcode'];

        if ($_POST['MN']) {
            $chkValue = $_POST['web'] . $webPwd . $_POST['buysafeno'] . $_POST['MN'] . $errorCode;
            if ($_POST['CargoNo'] != '') {
                $chkValue = $chkValue . $_POST['CargoNo'];
            }
        } else {
            $call_back_by_shipment = true;
            $chkValue = $_POST['web'] . $webPwd . $_POST['buysafeno'] . $_POST['StoreType'];
        }

        $chkValue = EncryptChkValue::getValue($chkValue);
        $response['chkValue'] = $this->verifyCallBack($chkValue);
        $response['shipment'] = $call_back_by_shipment;
        return $response;
    }
    /*
    public function CallBack($webPwd)
    {
        $call_back_by_shipment = false;
        $errorCode = $_POST['errcode'];
        $sendType = $_POST['SendType'];

        if ($sendType == 2) {
            $chkValue = $_POST['web'] . $webPwd . $_POST['buysafeno'] . $_POST['MN'] . $errorCode;
            if ($_POST['CargoNo'] != '') {
                $chkValue = $chkValue . $_POST['CargoNo'];
            }
        } elseif ($sendType == "" || $sendType == 1) {
            $call_back_by_shipment = true;
            $chkValue = $_POST['web'] . $webPwd . $_POST['buysafeno'] . $_POST['StoreType'];
        } else {
            throw new Exception('SendType mismatch');
        }

        $chkValue = EncryptChkValue::getValue($chkValue);
        $response['chkValue'] = $this->verifyCallBack($chkValue);
        $response['shipment'] = $call_back_by_shipment;
        return $response;
    }*/
}
class twPay extends SunPay
{
    public $sendExtendField = array();
    function __construct($payment,$shipment = null)
    {
        parent::__construct();
        $this->setCargoFlag($shipment);
    }
    public function CallBack($webPwd)
    {
        $call_back_by_shipment = false;
        $errorCode = $_POST['errcode'];

        if ($_POST['MN']) {
            $chkValue = $_POST['web'] . $webPwd . $_POST['buysafeno'] . $_POST['MN'] . $errorCode;
            if ($_POST['CargoNo'] != '') {
                $chkValue = $chkValue . $_POST['CargoNo'];
            }
        } else {
            $call_back_by_shipment = true;
            $chkValue = $_POST['web'] . $webPwd . $_POST['buysafeno'] . $_POST['StoreType'];
        }

        $chkValue = EncryptChkValue::getValue($chkValue);
        $response['chkValue'] = $this->verifyCallBack($chkValue);
        $response['shipment'] = $call_back_by_shipment;
        return $response;
    }


    /*
    public function CallBack($webPwd)
    {
        $call_back_by_paid = false;
        $call_back_by_shipment = false;
        $errorCode = isset($_POST['errcode']) ? $_POST['errcode'] : '';
        $sendType = isset($_POST['SendType']) ? $_POST['SendType'] : '';

        if ($sendType == 2) {
            $chkValue = $_POST['web'] . $webPwd . $_POST['buysafeno'] . $_POST['MN'] . $errorCode . $_POST['CargoNo'];
        } elseif ($sendType == "" || $sendType == 1) {
            if ($errorCode != '') {
                $call_back_by_paid = true;
                $chkValue = $_POST['web'] . $webPwd . $_POST['buysafeno'] . $_POST['MN'] . $errorCode;
            } elseif (isset($_POST['StoreType'])) {
                $call_back_by_shipment = true;
                $chkValue = $_POST['web'] . $webPwd . $_POST['buysafeno'] . $_POST['StoreType'];
            } else {
                throw new Exception('Unknown callback');
            }
        } else {
            throw new Exception('SendType mismatch');
        }

        $chkValue = EncryptChkValue::getValue($chkValue);
        $response['chkValue'] = $this->verifyCallBack($chkValue);
        $response['paid'] = $call_back_by_paid && $response['chkValue'];
        $response['shipment'] = $call_back_by_shipment && $response['chkValue'];
        return $response;
    }*/
}
class SunShip extends SunPay
{
    public $sendExtendField = array();
    function __construct($payment,$shipment = null)
    {
        parent::__construct();
        //var_dump($shipment);
        $this->setCargoFlag($shipment);
    }
    public function CallBack($webPwd)
    {
        $call_back_by_paid = false;
        $call_back_by_shipment = false;
        $errorCode = isset($_POST['errcode']) ? $_POST['errcode'] : '';
        $sendType = isset($_POST['SendType']) ? $_POST['SendType'] : '';

        if ($sendType == 2) {
            $chkValue = $_POST['web'] . $webPwd . $_POST['buysafeno'] . $_POST['MN'] . $errorCode . $_POST['CargoNo'];
        } elseif ($sendType == "" || $sendType == 1) {
            if ($errorCode != '') {
                $call_back_by_paid = true;
                $chkValue = $_POST['web'] . $webPwd . $_POST['buysafeno'] . $_POST['MN'] . $errorCode;
            } elseif (isset($_POST['StoreType'])) {
                $call_back_by_shipment = true;
                $chkValue = $_POST['web'] . $webPwd . $_POST['buysafeno'] . $_POST['StoreType'];
            } else {
                throw new Exception('Unknown callback');
            }
        } else {
            throw new Exception('SendType mismatch');
        }

        $chkValue = EncryptChkValue::getValue($chkValue);
        $response['chkValue'] = $this->verifyCallBack($chkValue);
        $response['paid'] = $call_back_by_paid && $response['chkValue'];
        $response['shipment'] = $call_back_by_shipment && $response['chkValue'];
        return $response;
    }
}

class Pay24 extends SunPay
{
    private $shipment;
    public $sendExtendField = array(
        'DueDate' => '',
        'UserNo' => '',
        'ProductName1' => '',
        'ProductPrice1' => 0,
        'ProductQuantity1' => 1,
        'AgencyType' => 1,
    );

    function __construct($payment,$shipment = null)
    {
        parent::__construct();
        $this->setCargoFlag($shipment);
    }

    public function checkOut($webPwd)
    {
        $this->sendExtendField['ProductPrice1'] = $this->sendField['MN'];
        return $this->checkOutHtmlParameters($webPwd);
    }

    public function CallBack($webPwd)
    {
        $call_back_by_paid = false;
        $call_back_by_shipment = false;
        $errorCode = isset($_POST['errcode']) ? $_POST['errcode'] : '';
        $sendType = isset($_POST['SendType']) ? $_POST['SendType'] : '';

        if ($sendType == 2) {
            $chkValue = $_POST['web'] . $webPwd . $_POST['buysafeno'] . $_POST['MN'] . $_POST['EntityATM'];
        } elseif ($sendType == "" || $sendType == 1) {
            if ($errorCode) {
                $call_back_by_paid = true;
                $chkValue = $_POST['web'] . $webPwd . $_POST['buysafeno'] . $_POST['MN'] . $errorCode;
                if ($_POST['CargoNo'] != '') {
                    $chkValue = $chkValue . $_POST['CargoNo'];
                }
            } else {
                $call_back_by_shipment = true;
                $chkValue = $_POST['web'] . $webPwd . $_POST['buysafeno'] . $_POST['StoreType'];
            }
        } else {
            throw new Exception('SendType mismatch');
        }

        $chkValue = EncryptChkValue::getValue($chkValue);
        $response['chkValue'] = $this->verifyCallBack($chkValue);
        $response['paid'] = $call_back_by_paid && $response['chkValue'];
        $response['shipment'] = $call_back_by_shipment && $response['chkValue'];
        return $response;
    }
}

class PayCode extends SunPay
{
    private $shipment;
    public $sendExtendField = array(
        'DueDate' => '',
        'UserNo' => '',
        'BillDate' => ''
    );

    function __construct($payment,$shipment = null)
    {
        parent::__construct();
        $this->setCargoFlag($shipment);
    }

    public function CallBack($webPwd)
    {
        $call_back_by_paid = false;
        $call_back_by_shipment = false;
        $errorCode = isset($_POST['errcode']) ? $_POST['errcode'] : '';
        $sendType = isset($_POST['SendType']) ? $_POST['SendType'] : '';

        if ($sendType == 2) {
            $chkValue = $_POST['web'] . $webPwd . $_POST['buysafeno'] . $_POST['MN'] . $_POST['paycode'];
        } elseif ($sendType == "" || $sendType == 1) {
            if ($errorCode) {
                $call_back_by_paid = true;
                $chkValue = $_POST['web'] . $webPwd . $_POST['buysafeno'] . $_POST['MN'] . $errorCode;
                if ($_POST['CargoNo'] != '') {
                    $chkValue = $chkValue . $_POST['CargoNo'];
                }
            } else {
                $call_back_by_shipment = true;
                $chkValue = $_POST['web'] . $webPwd . $_POST['buysafeno'] . $_POST['StoreType'];
            }
        } else {
            throw new Exception('SendType mismatch');
        }

        $chkValue = EncryptChkValue::getValue($chkValue);
        $response['chkValue'] = $this->verifyCallBack($chkValue);
        $response['paid'] = $call_back_by_paid && $response['chkValue'];
        $response['shipment'] = $call_back_by_shipment && $response['chkValue'];
        return $response;
    }
}

class AtmCode extends SunPay
{
    private $shipment;
    public $sendExtendField = array(
        'DueDate' => '',
        'UserNo' => '',
        'ProductName1' => '',
        'ProductPrice1' => 0,
        'ProductQuantity1' => 1,
        'AgencyType' => 2,
        'AgencyBank' => 'T',
    );

    function __construct($payment,$shipment = null)
    {
        parent::__construct();
        $this->setCargoFlag($shipment);
    }

    public function checkOut($webPwd)
    {
        $this->sendExtendField['ProductPrice1'] = $this->sendField['MN'];
        return $this->checkOutHtmlParameters($webPwd);
    }

    public function CallBack($webPwd)
    {
        //var_dump('callback',$webPwd);
        $call_back_by_paid = false;
        $call_back_by_shipment = false;
        $errorCode = isset($_POST['errcode']) ? $_POST['errcode'] : '';
        $sendType = isset($_POST['SendType']) ? $_POST['SendType'] : '';

        if ($sendType == 2) {
            $chkValue = $_POST['web'] . $webPwd . $_POST['buysafeno'] . $_POST['MN'] . $_POST['EntityATM'];
        } elseif ($sendType == "" || $sendType == 1) {
            if ($errorCode) {
                $call_back_by_paid = true;
                $chkValue = $_POST['web'] . $webPwd . $_POST['buysafeno'] . $_POST['MN'] . $errorCode;
                if ($_POST['CargoNo'] != '') {
                    $chkValue = $chkValue . $_POST['CargoNo'];
                }
            } else {
                $call_back_by_shipment = true;
                $chkValue = $_POST['web'] . $webPwd . $_POST['buysafeno'] . $_POST['StoreType'];
            }
        } else {
            throw new Exception('SendType mismatch');
        }

        $chkValue = EncryptChkValue::getValue($chkValue);
        $response['chkValue'] = $this->verifyCallBack($chkValue);
        $response['paid'] = $call_back_by_paid && $response['chkValue'];
        $response['shipment'] = $call_back_by_shipment && $response['chkValue'];
        return $response;
    }
}
class EncryptChkValue
{
    static function getValue($check_value)
    {
        return strtoupper(sha1($check_value));
    }
}
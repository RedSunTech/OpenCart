<?php

class ModelExtensionShippingSuntechlogistic extends Model
{
	private $module_name = 'suntechlogistic';

	// Constructor
	public function __construct($registry) {
		parent::__construct($registry);

		// Set the variables
		$this->lang_prefix = $this->module_name .'_';
		$this->setting_prefix = 'shipping_' . $this->module_name . '_';

	}

	public function getQuote($address) {
        
		$this->load->language('extension/shipping/suntechlogistic');
		
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "zone_to_geo_zone WHERE geo_zone_id = '" . (int)$this->config->get($this->setting_prefix . 'geo_zone_id') . "' AND country_id = '" . (int)$address['country_id'] . "' AND (zone_id = '" . (int)$address['zone_id'] . "' OR zone_id = '0')");
        $status = $this->config->get('shipping_suntechlogistic_status');

        $method_data = array();

        

        if ($status) {
			$quote_data = array();
            $methods = $this->config->get('shipping_suntechlogistic_methods')??[];
            $cost = $this->config->get('shipping_suntechlogistic_cost')??[];
            $EDIcost = $this->config->get('shipping_suntechlogistic_EDIcost')??[];
            $EDIsize = $this->config->get('shipping_suntechlogistic_EDIsize')??[];
            
            foreach($methods as $k => $v){
                if($k != 'E'){
                    $quote_data[$k] = array(
                        'code'         => 'suntechlogistic.'.$v,
                        'title'        => $this->language->get('suntechlogistic'.$v),
                        'cost'         => $cost[$v],
                        'tax_class_id' => 0,
                        'text'         => '$'.$cost[$v],
                    );
                }else{
                    $quote_data[$k] = array(
                        'code'         => 'suntechlogistic.'.$v,
                        'title'        => $this->language->get('suntechlogistic'.$v),
                        'cost'         => $EDIcost,
                        'tax_class_id' => 0,
                        'text'         => '$'.$EDIcost,
                    );
                }
            }
            
            $method_data = array(
                'code' => 'suntechlogistic',
                'title'      => $this->language->get('heading_title'),
                'quote'      => $quote_data,
                'sort_order' => '',
                'extra' 	 => '',
                'error'      => false
            );
        }
        
        /*
        if ($this->config->get('payment_suntech_24pay_cargo_option')) {
            $method_data['title'] .= "<p style='display: inline;color: tomato;'>（下一步可選擇是否<b>超商取貨</b>)</p>";
        }*/
		//var_dump($method_data);	
		return $method_data;
	}

}

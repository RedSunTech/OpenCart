<?php
class ControllerExtensionShippingsuntechLogistic extends Controller {

	// payment
	private $suntech_payment_module_name = 'suntechpayment';
	private $suntech_payment_module_path = '';

	// Logistic
	private $prefix = 'shipping_suntechlogistic_';
	private $suntech_logistic_module_name = 'suntechlogistic';
	private $suntech_logistic_module_path = '';
	private $suntech_logistic_payment_module_path = '';
	private $suntech_logistic_model_name = '';

	// invoice
    	private $suntech_invoice_module_name = 'suntechinvoice';
    	private $suntech_invoice_setting_prefix = '';


	// Constructor
	public function __construct($registry) {
		parent::__construct($registry);

		// Set the variables

		// payment
		$this->suntech_payment_module_path = 'extension/payment/' . $this->suntech_payment_module_name;
		$this->suntech_logistic_payment_module_path = 'extension/payment/' . $this->suntech_logistic_module_name;
		
		 // invoice
        	$this->suntech_invoice_setting_prefix = 'payment_' . $this->suntech_invoice_module_name . '_';

		// logistic
		$this->suntech_logistic_module_path = 'extension/shipping/' . $this->suntech_logistic_module_name;
		$this->suntech_logistic_model_name = 'model_extension_shipping_' . $this->suntech_logistic_module_name;

		$this->load->model($this->suntech_logistic_module_path);
		$this->{$this->suntech_logistic_model_name}->loadLibrary();
		$this->helper = $this->{$this->suntech_logistic_model_name}->getHelper();
	}

	public function index() {
		//var_dump('ControllerExtensionShippingsuntechLogistic/index');
	}




	





}
?>
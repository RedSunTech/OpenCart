<?php

class ControllerExtensionPaymentSuntechApplepay extends Controller
{
    private $payment = 'suntech_applepay';
    private $order_init_status = 1;
    private $EDI = ['S60','S90','S120','S150'];
    public function __construct($registry) {
        parent::__construct($registry);
    }
    // 訂單送出前 , 清空購物車 , 建立訂單
    public function saveOrder()
    {
        
        $data = array();

        $data['action'] = $this->config->get('payment_'.$this->payment . '_test_mode') ? 'https://test.esafe.com.tw/Service/Etopm.aspx' : 'https://www.esafe.com.tw/Service/Etopm.aspx';

        // Load language
        $this->language->load('extension/payment/' . $this->payment);
        // Load Order Model
        $this->load->model('checkout/order');

        $order_init_status = $this->order_init_status; // pending

        $account = $this->config->get('payment_'.$this->payment . '_account');
        $password = $this->config->get('payment_'.$this->payment . '_password');
        $order_id = $this->session->data['order_id'];

        $this->load->model('checkout/order');
        $this->load->model('extension/payment/' . $this->payment);
        $order_info = $this->model_checkout_order->getOrder($order_id);
        $payment_model = 'model_extension_payment_' . $this->payment;
        $shipment = isset($_POST['ship']) ? $_POST['ship'] : '';
 
        try {
            $include_result = $this->$payment_model->includeSunPay();
            if (!$include_result) {
                throw new Exception("Can't load sunpay model");
            }

            $total_amount = intval($this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false));
            $show = SunPayFactory::newSunPay($this->payment, $shipment);

            // 更新訂單運送方式、運費及目的地(暫不更新金額)
            /* if ($show->sendField['CargoFlag'] == 1) {
                $total_amount = $this->$payment_model->setOrderTotalsWithSunShip($order_id, $total_amount);
            }*/

            // 設定共用欄位
            $show->sendField['web'] = $account;
            $show->sendField['MN'] = $total_amount;
            $show->sendField['OrderInfo'] = '';
            $show->sendField['Td'] = $this->session->data['order_id'];
            $show->sendField['sna'] = html_entity_decode($order_info['payment_lastname'] . ' ' . $order_info['payment_firstname'], ENT_QUOTES, 'UTF-8');
            $show->sendField['sdt'] = $order_info['telephone'];
            $show->sendField['email'] = $order_info['email'];
            $show->sendField['note1'] = $order_id;
            $data['parameters'] = $show->checkOutHtmlParameters($password);
            //var_dump($data['parameters']);exit;
            
            $this->load->model('account/custom_field');
            $getCustomField = $this->model_account_custom_field->getCustomFields();
            $data['parameters']['EDI'] = SunPayFactory::EDI($password,$order_info, $_POST,$data['parameters']['CargoFlag'],$getCustomField);
            
			//var_dump($data['parameters']);exit;
            // Add Order History
            $order_history = $this->language->get('text_order_checkout') . ', ' . $this->language->get('text_title');

            
            $this->model_checkout_order->addOrderHistory($order_id, $order_init_status, $order_history, true);

        } catch (Exception $e) {
            $this->session->data['error'] = $e->getMessage();
            $checkout_url = $this->url->link('checkout/checkout', '', 'SSL');
            $this->response->redirect($checkout_url);
        }

        // 清空購物車
        if ($this->cart->hasProducts()) {
            $this->cart->clear();
        }

        $this->response->setOutput($this->load->view('extension/payment/sunpay', $data));
    }

    public function index()
    {
        $payment_type = $this->payment;
        $this->language->load('extension/payment/' . $payment_type);

        $data['button_confirm'] = $this->language->get('button_confirm');

        $action_url = $this->url->link('extension/payment/' . $payment_type . '/saveOrder', '', 'SSL');
        $data['action'] = $action_url;
        $data['payment'] = $payment_type;



        $cargo_option = $this->config->get('payment_'.$this->payment . '_cargo_option');
        $data['cargo_option'] = $cargo_option;
        $data['cargo_text'] = $this->language->get('cargo_text');
        // $data['cargo_notice'] = sprintf($this->language->get('cargo_notice'), $sun_ship_cost, $total);
        $data['cargo_notice'] = sprintf($this->language->get('cargo_notice'), 45, 145);
		
		
		$shipping_method = $this->session->data['shipping_method'];

        $data['ship_name'] = $shipping_method['title'];
        $data['ship'] = explode(".",$shipping_method['code'])[1];
        if($data['ship'] == 'E'){
            $data['EDItype'] = $this->config->get('shipping_suntechlogistic_EDItype');
            $data['EDIsize'] = $this->config->get('shipping_suntechlogistic_EDIsize');
        }
        $data['shipShow'] = explode(".",$shipping_method['code'])[0];
        
        $data['no_send'] = '0';

        $this->load->model('checkout/order');

        $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
        $data['no_send'] = '0';


        return $this->load->view('extension/payment/suntech', $data);
    }

    // 交易成功接收網址 or 交易失敗接收網址
    public function callback()
    {
        $payment_type = $this->payment;
        try {
            $this->language->load('extension/payment/' . $payment_type);
            $this->load->model('checkout/order');
            $this->load->model('extension/payment/' . $payment_type);
            $data = $this->request->post;
            $pwd = $this->config->get('payment_'.$payment_type . '_password');
            $data['continue'] = $this->url->link('common/home', '', 'SSL');
            $data['heading_title'] = $this->language->get('heading_title_error');
            $payment_model = 'model_extension_payment_' . $payment_type;
            $include_result = $this->$payment_model->includeSunPay();
            if (!$include_result) {
                throw new Exception("Can't load sunpay model");
            }
            $show = SunPayFactory::newSunPay($this->payment);
            $response = $show->CallBack($pwd);

            if (!$response['chkValue']) {
                throw new Exception('chkValue mismatch');
            }

            $order_id = $data['Td'];
            $order_info = $this->model_checkout_order->getOrder($order_id);

            if ($response['shipment']) {   //物流回傳
                if ($_POST["StoreType"] == '1010') { //用戶已領
                    $finish_status = 5;
                } elseif ($_POST["StoreType"] == '101') { //抵達門市
                    $finish_status = 3;
                } else {
                    $finish_status = $this->config->get('payment_'.$payment_type . '_order_status_id');
                }
                $message = $this->language->get('text_shippingmsg') . urldecode($_POST["StoreMsg"]) . (($_POST["StoreType"] != '') ? sprintf($this->language->get('text_ship_code'), $_POST["StoreType"]) : '');
                $this->model_checkout_order->addOrderHistory($order_id, $finish_status, $message, true);
                echo '0000';
                exit;
            } else {  
                
                if ($_POST["SendType"] == '1') { //繳費回傳
                    if ($data['errcode'] != '00') {
                        if ($order_info['order_status_id'] == $this->order_init_status) {
                            $message = sprintf($this->language->get('text_failure_notify') . '', $data['buysafeno'], $data['errcode'] . ((isset($data['errmsg']) ? '/' . urldecode($data['errmsg']) : '')));
                            $this->model_checkout_order->addOrderHistory($order_id, 10, $message, true);
                        }
                    } else {

                        if (isset($data['ApproveCode']) && $data['ApproveCode'] != '') {
                            $message = sprintf($this->language->get('text_success_notify'), $data['applepayno'], $data['ApproveCode'], $data['Card_NO']);
                        }
                        else {
                            $message = sprintf($this->language->get('text_unionpay_success_notify'), $data['applepayno']);
                        }
                        

                        if(!empty($data['PayType']))
                            $message .= $this->language->get('pay_type_' . $data['PayType']);
                        if ($data['CargoNo'] != '') {
                            
                            $ckship = SunPayFactory::success_ship($order_info['shipping_method']);

                            $message .= sprintf($this->language->get($ckship[0]), $data['CargoNo'], $ckship[1]);

                            /*$shipping_info = array(
                                'shipping_address_2' => sprintf($this->language->get('cargo_msg'), urldecode($data['StoreName']), $data['StoreID'])
                            );
                            $this->$payment_model->setOrderInfo($order_id, $shipping_info);*/

                        }
                        if ($order_info['order_status_id'] == $this->order_init_status) {
                            $this->model_checkout_order->addOrderHistory($order_id, $this->config->get('payment_'.$payment_type . '_order_status_id'), $message, true);
                        }

                        if($order_info['shipping_method'] != '宅配通' && $data['CargoNo'] != ''){
                                
                            $this->model_checkout_order->addOrderHistory($order_id, $this->config->get('payment_'.$payment_type . '_order_status_id'), sprintf($this->language->get('cargo_msg'), $order_info['shipping_method'].urldecode($data['StoreName']), $data['StoreID']), true);
                        }

                    }
                    echo '0000';
                    exit;
                } 
                
                //繳費回傳
                if ($data['errcode'] != '00' ) {
                    if ($order_info['order_status_id'] == $this->order_init_status) {
                        $message = sprintf($this->language->get('text_failure_notify') . '', $data['applepayno'], $data['errcode'] . ((isset($data['errmsg']) ? '/' . urldecode($data['errmsg']) : '')));
                        $this->model_checkout_order->addOrderHistory($order_id, 10, $message, true);
                    }
                    $data['text_response'] = '';
                    $data['text_message'] = sprintf($this->language->get('text_failure'), $data['errcode'] . ((isset($data['errmsg']) ? '/' . urldecode($data['errmsg']) : '')));
                    $data['text_message_wait'] = sprintf($this->language->get('text_failure_wait'), $this->url->link('common/home', '', 'SSL'));
                } else {
                    $data['heading_title'] = sprintf($this->language->get('heading_title'), $this->config->get('config_name'));
                    if (isset($data['ApproveCode']) && $data['ApproveCode'] != '') {
                        $message = sprintf($this->language->get('text_success_notify'), $data['applepayno'], $data['ApproveCode'], $data['Card_NO']);
                    }
                    else {
                        $message = sprintf($this->language->get('text_unionpay_success_notify'), $data['applepayno']);
                    }


                    if ($data['CargoNo'] != '') {
                        
                        $ckship = SunPayFactory::success_ship($order_info['shipping_method']);

                        $message .= sprintf($this->language->get($ckship[0]), $data['CargoNo'], $ckship[1]);

                    }
                    
                    if ($order_info['order_status_id'] == $this->order_init_status) {
                        $this->model_checkout_order->addOrderHistory($order_id, $this->config->get('payment_'.$payment_type . '_order_status_id'), $message, true);
                    }

                    if($order_info['shipping_method'] != '宅配通' && $data['CargoNo'] != ''){
                                
                        $this->model_checkout_order->addOrderHistory($order_id, $this->config->get('payment_'.$payment_type . '_order_status_id'), sprintf($this->language->get('cargo_msg'), $order_info['shipping_method'].urldecode($data['StoreName']), $data['StoreID']), true);
                    }

                    $data['text_response'] = $this->language->get('text_response') . " " . $data['ApproveCode'];
                    $data['text_message'] = $this->language->get('text_success');
                    $data['text_message_wait'] = sprintf($this->language->get('text_success_wait'), $this->url->link('checkout/success'));
                    $data['continue'] = $this->url->link('checkout/success', '', 'SSL');
                }
            }
        } catch (Exception $e) {
            $this->session->data['error'] = $e->getMessage();
            $checkout_url = $this->url->link('checkout/checkout', '', 'SSL');
            $this->response->redirect($checkout_url);
        }

        $data['charset'] = $this->language->get('charset');
        $data['language'] = $this->language->get('code');
        $data['direction'] = $this->language->get('direction');

        // 整合首頁的樣板
        $this->document->setTitle($this->config->get('config_meta_title'));
        $this->document->setDescription($this->config->get('config_meta_description'));
        $this->document->setKeywords($this->config->get('config_meta_keyword'));

        if (isset($this->request->get['route'])) {
            $this->document->addLink(HTTP_SERVER, 'canonical');
        }

        $data['column_left'] = $this->load->controller('common/column_left');
        $data['column_right'] = $this->load->controller('common/column_right');
        $data['content_top'] = $this->load->controller('common/content_top');
        $data['content_bottom'] = $this->load->controller('common/content_bottom');
        $data['footer'] = $this->load->controller('common/footer');
        $data['header'] = $this->load->controller('common/header');

        $this->response->setOutput($this->load->view('extension/payment/suntech_result', $data));
    }
}

<?php
class Controllerextensionpaymentsuntechfatfat extends Controller {
	private $module_name = 'suntechlogistic';
	private $mark_pay = [
		'suntech_24pay',
		'suntech_buysafe',
		'suntech_paycode',
		'suntech_webatm',
		'suntech_sunship',
		'suntech_unionpay',
		'suntech_applepay',
		'suntech_googlepay',
		'suntech_twpay',
		'suntech_atmcode',
	];
/*
	// Constructor
	public function __construct($registry) {
		parent::__construct($registry);
		
	}*/

	public function index(&$route, &$data, &$output) {
		//var_dump($this->session->data);
		if($data[0] == 'payment')
		{
		        $delivery_method_type = [
					$this->module_name.'.1',
					$this->module_name.'.2',
					$this->module_name.'.2B',
					$this->module_name.'.3',
					$this->module_name.'.4',
					$this->module_name.'.E',
					$this->module_name.'.S60',
					$this->module_name.'.S90',
					$this->module_name.'.S120',
					$this->module_name.'.S150',
					
				];
				//have mark pay

				//var_dump($output);
		        if( isset( $this->session->data['shipping_method']['code']) ) {
					$code = $this->session->data['shipping_method']['code'];
					//var_dump($code);
					
					// 判斷貨到付款
					$Cash_on_delivery = 0;//判斷是否要關閉   紅陽超商取貨（貨到付款）

		            if( in_array( $code, $delivery_method_type) ) {
						
						$output = $this->ck_output($output,$code,0);

						$Cash_on_delivery = 1;
					}

					if($Cash_on_delivery == 0){

						$output = $this->ck_output($output,$code,1);
					}
		        }

		        if (empty($data['payment_methods'])) {
					$data['error_warning'] = sprintf($this->language->get('error_no_payment'), $this->url->link('information/contact'));
				}
		}	
	}

	function ck_output($output,$code,$type){

		foreach($output as $k => $v ) {


			if($type == 0){
				if( in_array( $v['code'], $this->mark_pay) == false ){
					unset($output[$k]);
				}

				if($code == $this->module_name.'.E'){
					if( $v['code'] == 'suntech_sunship' )
						unset($output[$k]);	
				}
			}elseif($type == 1){

				if( $v['code'] == 'suntech_sunship' )
					unset($output[$k]);	

			}

		}


		return $output;

	}

	
}
